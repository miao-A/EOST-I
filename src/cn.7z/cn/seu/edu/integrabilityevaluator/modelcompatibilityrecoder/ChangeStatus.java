package cn.seu.edu.integrabilityevaluator.modelcompatibilityrecoder;


public enum ChangeStatus {
	UNCHANGED,MODIFIED
}

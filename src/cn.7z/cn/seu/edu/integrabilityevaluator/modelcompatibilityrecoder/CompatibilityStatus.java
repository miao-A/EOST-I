package cn.seu.edu.integrabilityevaluator.modelcompatibilityrecoder;

public enum CompatibilityStatus {
	COMPATIBILITY, UNCOMPATIBILITY
}

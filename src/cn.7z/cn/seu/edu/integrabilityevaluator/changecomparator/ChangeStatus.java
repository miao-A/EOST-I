package cn.seu.edu.integrabilityevaluator.changecomparator;


public enum ChangeStatus {
	UNCHANGED,MODIFIED
}
